
const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Code@007blue',  
  database: 'canteen_backend'     
});

db.connect(err => {
  if (err) {
    console.error('Error connecting to database:', err);
    return;
  }
  console.log('Connected to MySQL database');
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});

//create user
app.post('/api/users', (req, res) => {
    const { Username, Password, Email, PhoneNumber, Role } = req.body;
    const query = 'INSERT INTO Users (Username, Password, Email, PhoneNumber, Role) VALUES (?, ?, ?, ?, ?)';
    db.query(query, [Username, Password, Email, PhoneNumber, Role], (err, result) => {
        if (err) return res.status(500).send(err);
        res.status(201).send({ UserID: result.insertId });
    });
});

app.post('/api/users', (req, res) => {
    const { Username, Password, Email, PhoneNumber, Role } = req.body;
    if (!Username || !Password || !Email) {
        return res.status(400).send('Missing required fields');
    }
    
});

//get all users

app.get('/api/users', (req, res) => {
    const query = 'SELECT * FROM Users';
    db.query(query, (err, results) => {
        if (err) return res.status(500).send(err);
        res.status(200).send(results);
    });
});

//get all menu items
app.get('/api/menu-items', (req, res) => {
    const query = 'SELECT * FROM MenuItems WHERE Availability = "In Stock"';
    db.query(query, (err, results) => {
        if (err) return res.status(500).send(err);
        res.status(200).send(results);
    });
});
// create menu items
app.post('/api/menu-items', (req, res) => {
    const { ItemName, Description, Price, CategoryID, ImageURL } = req.body;
    const query = 'INSERT INTO MenuItems (ItemName, Description, Price, CategoryID, ImageURL) VALUES (?, ?, ?, ?, ?)';
    db.query(query, [ItemName, Description, Price, CategoryID, ImageURL], (err, result) => {
        if (err) return res.status(500).send(err);
        res.status(201).send({ ItemID: result.insertId });
    });
});


//create order
app.post('/api/orders', (req, res) => {
    const { UserID, TotalAmount, DeliveryAddress } = req.body;
    const query = 'INSERT INTO Orders (UserID, TotalAmount, DeliveryAddress) VALUES (?, ?, ?)';
    db.query(query, [UserID, TotalAmount, DeliveryAddress], (err, result) => {
        if (err) return res.status(500).send(err);
        res.status(201).send({ OrderID: result.insertId });
    });
});
//get orders by user
app.get('/api/orders/:userId', (req, res) => {
    const query = 'SELECT * FROM Orders WHERE UserID = ?';
    db.query(query, [req.params.userId], (err, results) => {
        if (err) return res.status(500).send(err);
        res.status(200).send(results);
    });
});
//create payment
app.post('/api/payments', (req, res) => {
    const { OrderID, PaymentMethod, Amount } = req.body;
    const query = 'INSERT INTO Payments (OrderID, PaymentMethod, Amount) VALUES (?, ?, ?)';
    db.query(query, [OrderID, PaymentMethod, Amount], (err, result) => {
        if (err) return res.status(500).send(err);
        res.status(201).send({ PaymentID: result.insertId });
    });
});

//create review
app.post('/api/reviews', (req, res) => {
    const { UserID, ItemID, Rating, Comment } = req.body;
    const query = 'INSERT INTO Reviews (UserID, ItemID, Rating, Comment) VALUES (?, ?, ?, ?)';
    db.query(query, [UserID, ItemID, Rating, Comment], (err, result) => {
        if (err) return res.status(500).send(err);
        res.status(201).send({ ReviewID: result.insertId });
    });
});







// Endpoint to save user preferences
app.post('/save-preferences', (req, res) => {
    const { userId, preferences } = req.body;

    if (!userId || !Array.isArray(preferences)) {
        return res.status(400).json({ error: 'Invalid input' });
    }

    // Delete existing preferences for the user
    db.query('DELETE FROM user_preferences WHERE User_ID = ?', [userId], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database error' });
        }

        // Prepare values for insertion
        const values = preferences.map(ingredient => [userId, ingredient]);

        // Insert new preferences
        const query = 'INSERT INTO user_preferences (User_ID, ingredient) VALUES ?';
        
        db.query(query, [values], (err) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ error: 'Database error' });
            }
            res.json({ message: 'Preferences saved' });
        });
    });
});



//error handling

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack); // Log the error for debugging
    res.status(500).json({
        success: false,
        message: 'Internal Server Error'
    });
});

app.post('/api/users', async (req, res, next) => {
    try {
        const { Username, Password, Email } = req.body;
        if (!Username || !Password || !Email) {
            return res.status(400).json({ success: false, message: 'Missing required fields' });
        }
        // Code to insert user into the database...
        res.status(201).json({ success: true, message: 'User created successfully' });
    } catch (error) {
        next(error); // Pass the error to the error-handling middleware
    }
});

app.post('/api/menu-items', async (req, res, next) => {
    try {
        const { ItemName, Price, CategoryID } = req.body;
        // Validate input...
        
        const result = await db.query('INSERT INTO MenuItems ...'); // Your insert logic
        res.status(201).json({ success: true, message: 'Menu item created', itemID: result.insertId });
    } catch (error) {
        if (error.code === 'ER_NO_REFERENCED_ROW_2') {
            return res.status(400).json({ success: false, message: 'Invalid CategoryID' });
        }
        next(error); // Pass to the general error handler
    }
});


const { body, validationResult } = require('express-validator');

app.post('/api/users', [
    body('Username').notEmpty().withMessage('Username is required'),
    body('Password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    body('Email').isEmail().withMessage('Invalid email format')
], async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
    }
    // Your user creation logic...
});


app.post('/api/orders', async (req, res, next) => {
    try {
        const { UserID, TotalAmount } = req.body;
        // Validate input...
        // Check if user exists...

        // Insert order logic...
        res.status(201).json({ success: true, message: 'Order created successfully' });
    } catch (error) {
        if (error.code === 'ER_NO_REFERENCED_ROW_2') {
            return res.status(400).json({ success: false, message: 'UserID does not exist' });
        }
        next(error);
    }
});

const winston = require('winston');

const logger = winston.createLogger({
    level: 'error',
    format: winston.format.json(),
    transports: [
        new winston.transports.File({ filename: 'error.log' })
    ],
});

app.use((err, req, res, next) => {
    logger.error(err.stack);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
});







//bkash
app.get('/payment-callback', async (req, res) => {
    const { paymentID } = req.query;
  
    if (!paymentID) {
      return res.status(400).send('Invalid callback: missing payment ID');
    }
  
    try {
      const response = await axios.post(`${BASE_URL}/checkout/payment/execute/${paymentID}`, {}, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'X-APP-Key': APP_KEY
        }
      });
  
      if (response.data && response.data.paymentID) {
        res.send('Payment successful: ' + JSON.stringify(response.data));
      } else {
        res.status(500).send('Payment verification failed');
      }
    } catch (error) {
      console.error('Error executing payment:', error.response.data);
      res.status(500).send('Error processing payment');
    }
  });
  